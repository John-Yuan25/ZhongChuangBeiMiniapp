Page({
  data: {
    selList: [],
    shareList: [],
  },
  eachShare(event) {
    let shareId = event.currentTarget.dataset.shareid
    wx.navigateTo({
      url: '/pages/shareOne/shareOne?shareId='+shareId,
    })
  },
  onLoad: function (options) {
    const that = this
    //标签
    wx.cloud.database().collection('selList').get()
    .then(res=>{ 
      console.log("11111111111",res.data);
      that.setData({
        selList: res.data
      })
    })
    .catch(err=>{
      console.log("请求失败",err);
    })
    //分享列表
    wx.cloud.database().collection('shareList').get()
    .then(res=>{ 
      console.log("222222222",res.data);
      that.setData({
        shareList: res.data
      })
    })
    .catch(err=>{
      console.log("请求失败",err);
    })
  }
})