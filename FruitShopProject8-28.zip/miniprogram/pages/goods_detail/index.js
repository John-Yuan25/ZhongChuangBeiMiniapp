// pages/goods_detail/index.js
let goods_id=''
let goods_label=0
var openid=''
var newnum=0
let mycollect=[]
let isCollect=0
Page({ 
  /**
   * 页面的初始数据
   */
  data: {
    goodsObj: {},
    isCollect:false,
    openid:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      console.log("获取的商品id",options.goods_label);
       goods_id=options.goods_id;
       goods_label=options.goods_label; 
       console.log( goods_label);
       wx.cloud.callFunction({ 
        name:'getOpenid'
      })
      .then(res=>{
        // console.log("获取用户openid成功",res.result.openid);
          openid=res.result.openid
      })
      .catch(res=>{
        console.log("获取用户openid失败",res);
      })

     
        wx.cloud.database().collection('allGoods')
        .doc(goods_id)
        .get()
        .then(res =>{
          // console.log("详情页的商品查找成功",res.data);
          this.setData({
            goodsObj:res.data
          })   
          // console.log(res.data.SwiperImg);   
        })
        .catch(err=>{
          console.log("详情页的商品查找失败nmd",err);
        })
       
       
 

      
       //判定用户是否收藏了该商品
       wx.cloud.callFunction({
        name:'getOpenid'
      })
      .then(res=>{
        // console.log("获取用户openid成功",res.result.openid);
          openid=res.result.openid
      })
      .then(res=>{
        wx.cloud.database().collection('users')
          .where({
            _openid:openid,
            mycollect:goods_id
          })
          .get()
          .then(res =>{
            mycollect=res.data[0].mycollect
            this.setData({
              isCollect:true
            })   
          })
          .catch(err=>{
            console.log("没有收藏该商品",err);
          })
      })
      .catch(res=>{
        console.log("获取用户openid失败",res);
      })
  
  },


  // 点击 加入购物车
  handleCartAdd() {
    // 1 获取数据库中的购物车 数组
    // console.log("购物车的商品id",goods_id);
    let goodsObj={}
    let db=wx.cloud.database();
    wx.showToast({
      title: '加入购物车成功',
      icon: 'success',
      // true 防止用户 手抖 疯狂点击按钮 
      mask: true
    });
    db.collection('users')
    .where({
      _openid:openid,
    })
    .get()
    .then(res=>{
        console.log("查商品ok",res.data);
        console.log(res.data[0].myGoodsCart);
        //判定是否存在购物车
        var isInGoodsCart=0;
        var lengthNumber=0;
        for(var i=0;i<res.data[0].myGoodsCart.length;i++){
          if(goods_id==res.data[0].myGoodsCart[i].goods_id){
            isInGoodsCart=1;
            lengthNumber=i;
          }
        }
        //不存在，第一次添加
        if(isInGoodsCart==0){
          wx.cloud.callFunction({  
            name:'updateGoodsCart',
            data:{   
              goods:this.data.goodsObj,
              goods_id:goods_id,
              num:1,
              openid,
              goodsOption:0
            } 
          })
          .then(res =>{  
            console.log("更改购物车返回的event",res);
       }) 
       .catch(err=>{
         console.log("加入购物车失败",err); 
       })
        }
           //存在，数量加一
           if(isInGoodsCart==1){
            wx.cloud.callFunction({  
              name:'updateGoodsCart',
              data:{                 
                goods:this.data.goodsObj, 
                goods_id:goods_id,
                openid,
                goodsOption:1,
                lengthNumber
              } 
            })
            .then(res =>{  
              console.log("更改购物车返回的event",res);
            // wx.showToast({
            //   title: '加入购物车成功',
            //   icon: 'success',
            //   // true 防止用户 手抖 疯狂点击按钮 
            //   mask: true
            // });
         
         }) 
         .catch(err=>{
           console.log("加入购物车失败",err);
         })
           }

    })
    .catch(res=>{
      console.log("获取购物车信息失败",res);
    })

  },


  //点击 收藏加入或取消

  handleCollect(){
    //判定用户是否收藏了该商品

    wx.cloud.callFunction({
      name:'getOpenid'
    })
    .then(res=>{
      // console.log("获取用户openid成功",res.result.openid);
        openid=res.result.openid
    })
    .then(res=>{ 
      wx.cloud.database().collection('users')
        .where({
          _openid:openid,
          mycollect:goods_id
        }) 
        .get()
        .then(res =>{
          //查询到，说明已经收藏，点击取消收藏
          mycollect=res.data[0].mycollect
           //弹窗显示
        wx.showToast({ 
          title: '取消成功',
          icon: 'success',
          mask: true
        });
        //改变图标
        this.setData({
          isCollect:false
        })

          wx.cloud.callFunction({  
            name:'updateCollect',
            data:{   
              openid,
              goods_id, 
              collectionOption:1  
            } 
          })
          .then(res =>{  
            console.log("调用收藏返回的event",res); 
       }) 
       .catch(err=>{
         console.log("收藏失败",err);
       })
         
        })
        .catch(err=>{  
          //没查到说明还没收藏，点击收藏 
          console.log("没有收藏该商品",err);
          // console.log("该商品的id",goods_id);
            //弹窗显示 
         wx.showToast({
          title: '收藏成功',
          icon: 'success', 
          mask: true  
        }); 
          //改变图标 
          this.setData({
            isCollect:true
          })
          wx.cloud.callFunction({ 
            name:'updateCollect',
            data:{    
              openid,
              goods_id,   
              collectionOption:0
             }  
          })
          .then(res =>{   
            console.log("返回的event",res);
       }) 
       .catch(err=>{
         console.log("收藏失败",err);
       })
             
        })
    })
    .catch(res=>{
      console.log("获取用户openid失败",res);
    })
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
 
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})