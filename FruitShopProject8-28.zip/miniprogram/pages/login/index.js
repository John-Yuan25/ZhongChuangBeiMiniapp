// pages/login/index.js
let openid=""
Page({
  data:{
  
  },
  onLoad(){
    //调用云函数获取用户的openid
    wx.cloud.callFunction({
      name:'getOpenid'
    })
    .then(res=>{
      // console.log("获取用户openid成功",res.result.openid);
        openid=res.result.openid
    })
    .catch(res=>{
      console.log("获取用户openid失败",res);
    })
  },

  handleGetUserInfo(e){
      console.log(e.detail);
      var detail=e.detail;
      let db=wx.cloud.database();
    db.collection('users')
    .where({
      _openid:openid
    })
    .get()
    .then(res=>{
      if(res.data.length==0){
        // console.log("查询用户id",res.data);
        //如果数据库中没有用户数据就插入数据库
        wx.cloud.database().collection('users')
        .add({
          data:{
            detail,
            mycollect:[],
            myPayOrder:[],
            myUnpayOrder:[],
            myGoodsCart:[]
          }
        })
        .then(res=>{
          console.log('添加用户成功',res);
          wx.navigateBack({
            delta: 1
          });
        })
        .catch(res=>{
          console.log('添加用户失败',res);
        })
      }
      else{
        wx.navigateBack({
          delta: 1
        });
      }
    })
    .catch(err=>{
      console.log("找不到用户id",res);
    })    
  }
})