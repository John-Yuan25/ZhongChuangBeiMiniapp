// pages/pay/index.js
let openid=""
let goodlist=''
var goodsId=[]
var cartList=[]
var priceSum=0
var goodsNumSum=0
var addressMessage={}
Page({

  /**
   * 页面的初始数据
   */
  data: {
    address: {},
    cart: [],
    totalPrice: 0,
    totalNum: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.chooseAddress({
      success: (result) => {
        console.log(result);
        addressMessage=result
       
        this.setData({
          address:result
        })
      },
    })
    console.log(this.data.totalPrice);
    //调用云函数获取用户的openid
    wx.cloud.callFunction({
     name:'getOpenid'
   })
   .then(res=>{
     // console.log("获取用户openid成功",res.result.openid);
       openid=res.result.openid
       let db=wx.cloud.database();
       db.collection('users')
          .where({
            _openid:openid
          })
          .get()
          .then(res=>{
            console.log("user购物车里面的res",res.data[0].myGoodsCart);
           //  goodlist=res.data
           var goodsCart=res.data[0].myGoodsCart
           goodsCart.forEach((val,index)=>
           //  console.log(index,val.goods_id,val.num)
             goodsId[index]=val.goods_id,       
            );
            goodsCart.forEach((val,index)=>
            //  console.log(index,val.goods_id,val.num)
            cartList[index]=val
             );    
             priceSum=0
             goodsCart.forEach((val,index)=>
            //  console.log(index,val.goods_id,val.num)
            priceSum=(val.goods.price*val.num)+priceSum
             );  
             goodsNumSum=0
             goodsCart.forEach((val,index)=>
            //  console.log(index,val.goods_id,val.num)
            goodsNumSum=val.num+goodsNumSum
             );  
           //  console.log("ididid", goodsId),
            this.setData({
             goods_ID:goodsId
            }),
            this.setData({
            cart:cartList
            }),
           //  console.log("IDIDID", this.data.goods_ID)
            this.setData({
            goodList:res.data     
          })
          this.setData({
            totalPrice:priceSum 
          })
          this.setData({
            totalNum:goodsNumSum
          })
         })
          .catch(res=>{
            console.log("获取购物车数据失败",res);
          })
   })
   .catch(res=>{
     console.log("获取用户openid失败",res);
   })

  },
  handleOrderPay(){
    wx.showModal({
      title:'支付',
      content:'确定支付吗？',
      success (res) {
        if (res.confirm) {
          console.log("传过去的cart",cartList);
          wx.navigateTo({
            url: '/pages/order/index'
          });
          //调用云函数传递数据到待收货订单集合
          wx.cloud.callFunction({  
            name:'updateReceiveOrder',
            data:{   
              addressMessage,
              goodsId, 
              priceSum,
              cartList,
              openid,
              payOption:1
            } 
          })
          .then(res =>{  
            console.log("上传待收货订单返回的event",res);
            wx.cloud.callFunction({  
              name:'updateGoodsCart',
              data:{   
                openid,
                goodsOption:3,
              } 
            })
       }) 
       .catch(err=>{
         console.log("订单上传失败",err);
       })


        } else if (res.cancel) {
          wx.navigateTo({
            url: '/pages/order/index'
          });
           //调用云函数传递数据到待收货订单集合
           wx.cloud.callFunction({  
            name:'updateReceiveOrder',
            data:{   
              addressMessage,
              goodsId, 
              priceSum,
              cartList,
              openid,
              payOption:0
            } 
          })
          .then(res =>{  
            console.log("上传待付款订单返回的event",res);
            wx.cloud.callFunction({  
              name:'updateGoodsCart',
              data:{   
                openid,
                goodsOption:3,
              } 
            })
       }) 
       .catch(err=>{
         console.log("订单上传失败",err);
       })
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})