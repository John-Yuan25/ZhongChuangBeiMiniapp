// pages/addShare/addShare.js
Page({
  data: {
    pos: '',
    open: false,
    placehoderTxt: '你写的文字我们都很喜欢~',
    msgCon: '',
    imgs: [],
    video: '',
    lenMore: 0,
    addList: {
      collect: 0,
      comment:[],
      commentNum: 0,
      isImg: null,
      link: '',
      love: 0,
      shareImg: '',
      shareStr: '',
      title: '',
      userImg: '',
      userName: '',
      type: '',
    },
    comList:{
      content: '',
      name: '',
      time: '',
      userImg: '',
    },
    selectShow: false,//控制下拉列表的显示隐藏，false隐藏、true显示
    selectData: ['水果','蔬菜','海鲜'],//下拉列表的数据
    index: 0,//选择的下拉列表下标

  },
  // 点击下拉显示框
  selectTap() {
    this.setData({
      selectShow: !this.data.selectShow
    });
  },
  // 点击下拉列表
  optionTap(e) {
    let Index = e.currentTarget.dataset.index;//获取点击的下拉列表的下标
    this.setData({
      index: Index,
      selectShow: !this.data.selectShow
    });
    console.log("5555555", this.data.selectData[this.data.index])
  },
  transPos(){
    this.setData({
      pos:'absolute'
    })
  },
  toggle:function () {
    this.setData({
      pos:'fixed'
    })
    this.setData({
      open:!this.data.open
    })
  },
  // 上传图片
  chooseImg: function (e) {
    var that = this;
    var imgs = this.data.imgs;
    if (imgs.length >= 9) {
      this.setData({
        lenMore: 1
      });
      setTimeout(function () {
        that.setData({
          lenMore: 0
        });
      }, 2500);
      return false;
    }
    wx.chooseImage({
      // count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        var tempFilePaths = res.tempFilePaths;
        var imgs = that.data.imgs;
        for (var i = 0; i < tempFilePaths.length; i++) {
          if (imgs.length >= 9) {
            that.setData({
              imgs: imgs
            });
            return false;
          } else {
            imgs.push(tempFilePaths[i]);
          }
        }
        console.log(imgs);
        that.setData({
          imgs: imgs,
          ['addList.isImg']: true
        });
        console.log(that.data.addList)
      }
    });
  },
  // 删除图片
  deleteImg: function (e) {
    var imgs = this.data.imgs;
    var index = e.currentTarget.dataset.index;
    imgs.splice(index, 1);
    this.setData({
      imgs: imgs
    });
    if (this.data.imgs.length<1) {
      this.setData({['addList.isImg']: null})
    }
  },
  // 预览图片
  previewImg: function (e) {
    //获取当前图片的下标
    var index = e.currentTarget.dataset.index;
    //所有图片
    var imgs = this.data.imgs;
    wx.previewImage({
      //当前显示图片
      current: imgs[index],
      //所有图片
      urls: imgs
    })
  },
  // 上传视频
  chooseVideo() {
    // 弹层  
    wx.showToast({
      title: '视频和图片只能选择上传一种类型!',
      icon: 'none',
      duration: 2000,
      success: res => {
        wx.chooseVideo({
          sourceType: ['album', 'camera'],
          compressed: true,
          maxDuration: 10,
          camera: 'back',
          success: res => {
            console.log(res);
            const video = res.tempFilePath;
            this.setData({ 
              video,
              ['addList.isImg']: false
            })
            return false
          }
        })
      }
    })
  },
  // 删除视频
  videoDelete() {
    let that =this
    wx.showModal({
      title: '警告',
      content: '确定要删除该视频吗',
      success: res => {
        if (res.confirm) {
          that.setData({
            video: '',
            ['addList.isImg']: null
          })
        }
      }
    })
  },
  onLoad: function (options) {
    
  },
})