// pages/searchResult/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list:[],
    failImgUrl:"https://636c-cloud1-7gtek86ne1d2e3a6-1306390996.tcb.qcloud.la/%E6%B4%BE%E8%92%99%E9%97%AE%E5%8F%B7.jfif"
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var searchValue=options.searchValue;
    let db=wx.cloud.database()
//所有商品类里面找
    db.collection('allGoods')
    .where({
      name:db.RegExp({ 
        regexp:searchValue,
        options:'i',
      }),
    })
    .get()
    .then(res=>{ 
      console.log("查询成功",res);
      if(res.data.length!=0){
        this.setData({
          list:res.data 
        })
        console.log("搜索里面的data",res.data);
        console.log("搜索里面的list", this.data.list);
      }
     else{
      this.setData({
        fail:"找不到商品"
      })
     }
    })
    .catch(err=>{
      console.log("查询失败",err);
    })
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})