// pages/index/index.js

let  searchValue=""
Page({

  /**
   * 页面的初始数据
   */
  data: {
    BackGroundImgUrl:"",
    labelPat:[],
    Fruitslist:[],
    Fishlist:[],
    FishTanklist:[],
    fruitSwiperHeight:0, 
    fishSwiperHeight:0, 
    fishTankSwiperHeight:0, 
    swiperHeight:0, 
    currentTab: 0,
  },


//获取用户输入的商品名
getSearch(e){
  searchValue=e.detail.value;
},
//点击搜索跳转到搜索结果页面
toSearchResult(){
  if(searchValue==''){
    wx.showToast({
      icon:'none',
      title: '商品名为空！',
      duration: 1500,
    })
  }
  else{
    wx.navigateTo({
      url: '/pages/searchResult/index?searchValue=' + searchValue,
    })
  }
},

  //滑动切换
  swiperTab: function (e) {
    var that = this;
    that.setData({
      currentTab: e.detail.current
    });
    if(that.data.currentTab==0){
      that.setData({
        swiperHeight:that.data.fruitSwiperHeight
      })
    }
    else if(that.data.currentTab==1){
      that.setData({
        swiperHeight:that.data.fishSwiperHeight
      })
    }else{
      that.setData({
        swiperHeight:that.data.fishTankSwiperHeight
      })
    }
  },
//点击切换
clickTab: function (e) {
  var that = this;
  if (this.data.currentTab === e.target.dataset.current) {
    return false;
  } else {
    that.setData({
      currentTab: e.target.dataset.current
    })
  } 
}, 
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //获取水果信息
    wx.cloud.database().collection('fruitsGoods').get()
    .then(res=>{ 
      console.log("商品请求成功",res.data.length);
        this.setData({
        Fruitslist:res.data ,
        fruitSwiperHeight:res.data.length*240+120,
        swiperHeight:res.data.length*240+120
      })
    })
    .catch(err=>{
      console.log("请求失败",err);
    })

    // 获取鱼类信息
    wx.cloud.database().collection('fishGoods').get()
    .then(res=>{ 
      console.log("商品请求成功",res.data.length);
        this.setData({
        Fishlist:res.data ,
        fishSwiperHeight:res.data.length*240+120
      })
    })
    .catch(err=>{
      console.log("请求失败",err);
    })

    //获取鱼缸信息
    wx.cloud.database().collection('fishTankGoods').get()
    .then(res=>{ 
      console.log("商品请求成功",res.data.length);
        this.setData({
          FishTanklist:res.data ,
          fishTankSwiperHeight:res.data.length*240+120
      })
    })
    .catch(err=>{
      console.log("请求失败",err);
    })

    //获取商品类型
    wx.cloud.database().collection('labelPattern').get()
    .then(res=>{ 
      console.log("商品类型请求成功",res);
      this.setData({
        labelPat:res.data,
      })
    })
    .catch(err=>{
      console.log("请求失败",err);
    })
   

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
 
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})