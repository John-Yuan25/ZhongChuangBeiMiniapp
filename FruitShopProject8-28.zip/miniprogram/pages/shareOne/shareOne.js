Page({
  data:{
    shareId: '',
    listOne: {},
  },
  onLoad : function(option) {
    this.setData({
      shareId: option.shareId
    })
    let that = this
    const db = wx.cloud.database()
    db.collection('shareList').where({
      _id: that.data.shareId
    }).get()
    .then(res=>{ 
      console.log("444444444",res.data);
      that.setData({
        listOne: res.data
      })
    })
    .catch(err=>{
      console.log("请求失败",err);
    })
  }
})