// pages/user/index.js
let openid=""
Page({
  data: {
    userinfo:{},
  },
  onLoad(){
    wx.cloud.callFunction({
      name:'getOpenid'
    })
    .then(res=>{
      // console.log("获取用户openid成功",res.result.openid);
        openid=res.result.openid
    })
    .catch(res=>{
      console.log("获取用户openid失败",res);
    })
  },
  onShow(){
    let db=wx.cloud.database();
    db.collection('users')
    .where({
      _openid:openid
    })
    .get()
    .then(res=>{
      console.log("返回的用户数据",res.data[0].detail.userInfo);
       this.setData({
        userinfo:res.data[0].detail.userInfo
       })
    })
    .then(res=>{
      console.log("userinfo里面的",this.data.userinfo);
    })
    .catch(err=>{
      console.log("找不到用户id",err);
    })
      
  }
})