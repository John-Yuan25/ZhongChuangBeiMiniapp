// pages/myCollect/index.js
var openid=''
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list:[],
    // failImgUrl:"https://636c-cloud1-7gtek86ne1d2e3a6-1306390996.tcb.qcloud.la/%E6%B4%BE%E8%92%99%E9%97%AE%E5%8F%B7.jfif"
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let db=wx.cloud.database()
    var newList=[]
    var i=0
    wx.cloud.callFunction({
      name:'getOpenid'
    })
    .then(res=>{
      // console.log("获取用户openid成功",res.result.openid);
        openid=res.result.openid
    })
    .then(res=>{ 
      wx.cloud.database().collection('users')
        .where({
          _openid:openid,
        }) 
        .get()
        .then(res=>{
          // console.log("返回的user",res.data[0].mycollect);
         
          for(i;i<res.data[0].mycollect.length;i++){
             db.collection('allGoods')
            .where({
              _id:res.data[0].mycollect[i],
            })
            .get()
            .then(res=>{ 
              console.log("查询成功",res.data[0]);    
              if(res.data.length!=0){
                newList.push(res.data)
                // this.setData({
                //   ["list["+i+"]"]:res.data[0]
                //   // list:res.data
                // })
          
              }
             else{
              this.setData({
                fail:"找不到商品"
              })
             }
            })
            .catch(err=>{
              console.log("查询失败",err);
            })
          }

        })
        .catch(err=>{
          console.log(err);
        })
        
         //待优化，改为异步请求
                setTimeout(()=>{
                  for(var j=0;j<newList.length;j++){
                    this.setData({
                      // list:newList
                      ["list["+j+"]"]:newList[j][0]
                    })
                  }   
                  // console.log("这是newlist",newList);
                  // console.log("这是list",this.data.list);
                },2000)
              
      })
      .catch(res=>{
        console.log("获取用户openid失败",res);
      })

    
   
    
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})