// pages/cart/index.js
let openid=""
let goodlist=''
Page({

  /**
   * 页面的初始数据
   */
  data: {
    address: {},
    cart: {},
    goods_ID:[],
    allChecked: false,
    totalPrice: 0,
    totalNum: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(this.data.totalPrice);
    //调用云函数获取用户的openid
    wx.cloud.callFunction({
     name:'getOpenid'
   })
   .then(res=>{
     // console.log("获取用户openid成功",res.result.openid);
       openid=res.result.openid
       let db=wx.cloud.database();
       db.collection('users')
          .where({
            _openid:openid
          })
          .get()
          .then(res=>{
            console.log("user购物车里面的res",res.data[0].myGoodsCart);
           //  goodlist=res.data
           var goodsCart=res.data[0].myGoodsCart
           var goodsId=[]
           var cartList=[]
           var priceSum=0
           var goodsNumSum=0
           goodsCart.forEach((val,index)=>
           //  console.log(index,val.goods_id,val.num)
             goodsId[index]=val.goods_id,       
            );
            goodsCart.forEach((val,index)=>
            //  console.log(index,val.goods_id,val.num)
            cartList[index]=val
             );    
             goodsCart.forEach((val,index)=>
            //  console.log(index,val.goods_id,val.num)
            priceSum=(val.goods.price*val.num)+priceSum
             );  
             goodsCart.forEach((val,index)=>
            //  console.log(index,val.goods_id,val.num)
            goodsNumSum=val.num+goodsNumSum
             );  
           //  console.log("ididid", goodsId),
            this.setData({
             goods_ID:goodsId
            }),
            this.setData({
            cart:cartList
            }),
           //  console.log("IDIDID", this.data.goods_ID)
            this.setData({
            goodList:res.data     
          })
          this.setData({
            totalPrice:priceSum 
          })
          this.setData({
            totalNum:goodsNumSum
          })
         })
          .catch(res=>{
            console.log("获取购物车数据失败",res);
          })
   })
   .catch(res=>{
     console.log("获取用户openid失败",res);
   })

  },

  //点击获取收货地址
  handleChooseAddress(){
    wx.chooseAddress({
      success: (result) => {
        console.log(result);
        this.setData({
          address:result
        })
      },
    })
  },


// // 商品数量的编辑功能
handleItemNumEdit(e) {
  // 1 获取传递过来的参数 
  console.log("加减事件",e.currentTarget.dataset);
  let goods_id=e.currentTarget.dataset.id
  let operation=e.currentTarget.dataset.operation
  let newnum=0
  var isInGoodsCart=0;
  var lengthNumber=0;
  let db=wx.cloud.database();
  db.collection('users')
     .where({
       _openid:openid,
     })
     .get()
     .then(res=>{
      for(var i=0;i<res.data[0].myGoodsCart.length;i++){
        if(goods_id==res.data[0].myGoodsCart[i].goods_id){
          isInGoodsCart=1;
          lengthNumber=i;
        }
      }
       console.log("返回的加减事件",res.data[0].myGoodsCart[lengthNumber].num);
        newnum=res.data[0].myGoodsCart[lengthNumber].num+operation
        console.log("此时的num",newnum);
     })
     .then(res=>{
        //等于0就去掉商品
       if(newnum==0){ 
        // db.collection('users')
        // .where({
        //   _openid:openid,
        // }).remove({

        // })
        // .then(res=>{
        //   console.log(res);
        //   this.onLoad()
        // })
        // .catch(res=>{
        //   console.log(res);
        // })
        wx.cloud.callFunction({  
          name:'updateGoodsCart',
          data:{   
            goods_id:goods_id,
            openid,
            goodsOption:2,
            lengthNumber
          } 
        })
        .then(res =>{  
          console.log("更改购物车返回的event",res);
          this.onLoad()
     }) 
     .catch(err=>{
       console.log("更改购物车失败",err); 
     })
       }
       else{
        db.collection('users')
        .where({
          _openid:openid,
        })
        .update({
         data:{
          ["myGoodsCart."+[lengthNumber]+".num"]:newnum,
         },
       })
       .then(res=>{
        console.log("更改购物车返回的event",res);
         this.onLoad()
       })
       .catch(res=>{
         console.log(res);
       })
       } 
     })
     .catch(res=>{
       console.log(res);
     })
},

// // 点击 结算 
handlePay(){
    // 1 判断收货地址
  const {address,totalNum}=this.data;
  // if(!address.userName){
  //   wx.showToast({
  //     title: '您还没填收货地址',
  //     icon: 'none',
  //   });
  //   return;
  // }
    // 2 判断用户有没有选购商品
  if(totalNum===0){
    wx.showToast({
      title:"您还没有选购商品",
      icon: 'none',
    });
    return ;
  }
    // 3 跳转到 支付页面
  wx.navigateTo({
    url: '/pages/pay/index'
  });
},
// async handlePay(){
//   // 1 判断收货地址
//   const {address,totalNum}=this.data;
//   if(!address.userName){
//     await showToast({title:"您还没有选择收货地址"});
//     return;
//   }
//   // 2 判断用户有没有选购商品
//   if(totalNum===0){
//     await showToast({title:"您还没有选购商品"});
//     return ;
//   }
  // 3 跳转到 支付页面
//   wx.navigateTo({
//     url: '/pages/pay/index'
//   });
// },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   this.onLoad()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.onLoad()
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})