// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env:cloud.DYNAMIC_CURRENT_ENV
})
const db = cloud.database()
const _ = db.command
// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  var lengthNumber=event.lengthNumber
    //第一次加入购物车
      if(event.goodsOption==0){
        var goodsCart={
          goods_id:event.goods_id,
          num:event.num,
          goods:event.goods
        }
        try{
          await db.collection('users')
          .where({
            _openid:event.openid,
          })
          .update({
            data:{
              myGoodsCart:_.push([goodsCart])
            }
          })
        } catch(err){
          console.log("调用云函数失败",err);
        }
      }
       //不是第一次加入购物车
      if(event.goodsOption==1){
        try{
          await db.collection('users')
          .where({
            _openid:event.openid,
            'myGoodsCart.goods_id':event.goods_id
          })
          .update({
            data:{
              ["myGoodsCart."+[lengthNumber]+".num"]:_.inc(1),
            }
          })
        } catch(err){
          console.log("调用云函数失败",err);
        }
      }
      //修改购物车数据---删除商品
      if(event.goodsOption==2){   
        let goodsId=event.goods_id
        try{
          await db.collection('users')
          .where({
            _openid:event.openid,
            'myGoodsCart.goods_id':event.goods_id
          })
          .update({
            data:{
                 myGoodsCart:_.pull({
                  goods_id:goodsId
                 })
            }
          })
        } catch(err){
          console.log("调用云函数失败",err);
        }
      }
        //支付订单后购物车重置
      if(event.goodsOption==3){   
        let goodsId=event.goods_id
        try{
          await db.collection('users')
          .where({
            _openid:event.openid,
          })
          .update({
            data:{
                 myGoodsCart:_.remove(),
                 myGoodsCart:_.set([])
            }
          })
        } catch(err){
          console.log("调用云函数失败",err);
        }
      }
     
    

  return {
    event,
    openid: wxContext.OPENID,
    appid: wxContext.APPID,
    unionid: wxContext.UNIONID,
  }
}