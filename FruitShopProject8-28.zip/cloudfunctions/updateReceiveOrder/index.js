// 云函数入口文件
const cloud = require('wx-server-sdk')


cloud.init({
  env:cloud.DYNAMIC_CURRENT_ENV
})
const db = cloud.database()
const _ = db.command
// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()

  //已经付款
  if(event.payOption==1){
    var receiveOrder={
      goodsId:event.goodsId,
      addressMessage:event.addressMessage,
      priceSum:event.priceSum,
      cartList:event.cartList,
      btnText:'待收货'
    }
    try{
      await db.collection('users')
      .where({
        _openid:event.openid,
      })
      .update({
        data:{
          myPayOrder:_.push([receiveOrder])
        }
      })
    } catch(err){
      console.log("调用云函数失败",err);
    }
  }
  //代付款
  else{
    var waitForPayOrder={
      goodsId:event.goodsId,
      addressMessage:event.addressMessage,
      priceSum:event.priceSum,
      cartList:event.cartList,
      btnText:'待付款'
    }
    try{
      await db.collection('users')
      .where({
        _openid:event.openid,
      })
      .update({
        data:{
          myUnpayOrder:_.push([waitForPayOrder])
        }
      })
    } catch(err){
      console.log("调用云函数失败",err);
    }
  }





  return {
    event,
    openid: wxContext.OPENID,
    appid: wxContext.APPID,
    unionid: wxContext.UNIONID,
  }
}